"""SRAI module."""
